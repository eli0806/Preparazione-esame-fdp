L'**informatica** presenta più definizioni :
1) scienza della rappresentazione e dell’elaborazione dell’informazione
2) studio sistematico degli algoritmi che descrivono e trasformano l’informazione, la loro teoria e analisi, il loro progetto, e la loro efficienza, realizzazione e applicazione.

**Calcolatori Elettronici** = esecutori di algoritmi.

Gli [**algoritmi**](Algoritmi.md) vengono descritti tramite **programmi**.

**Programmi**=sequenze di istruzioni scritte in un opportuno linguaggio comprensibile al calcolatore.