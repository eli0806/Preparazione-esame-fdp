Abbiamo una coppia di conigli, che si possono riprodurre da un mese di età. Ogni femmina produce sempre una nuova coppia ogni mese .
Quante coppie ci sono dopo un anno?

mese 1: 1
mese 2: 1
mese 3: 1+1
mese 4: 1+1+1
mese 5: 1+1+1+1+1

insomma legge matematica n=n precedente+ n precedente-1

Si tratta di successione --> ciò riporta alla rappresentazione dei numeri reali !

Si usano i numeri naturali ! 

a=A-Bias 

Bias= (2^(p-1) -1)

La loro rappresentazione ha come intervallo [-(2^(p-1)+1) , 2^(p-1) ]  //Sbilanciamento verso i numeri negativi. ( -bias, bias)

Con 0 nel bit più significativo vengono rappresentati tutti i numeri negativi o nulli , con 1 quelli positivi quando si usa la tecnica del bias.

Però si può rappresentare solo una parte di tutto l'insieme R , mediante un'opportuna sequenza di P bit appunto--> si parla di budget di P cifre binarie .

Ad ogni cifra alpha si associa un peso beta.

Si ottiene con una generalizzazione della sommatoria .
(1010.101)b=2 r appartenente ai reali.

			2^3 + 2^1 + 2^-1 +2^-3 = 10 + 0,5 + 0,125 = 10,625



Per fare l'operazione inversa si usa l'algoritmo della parte frazionale e della parte intera .