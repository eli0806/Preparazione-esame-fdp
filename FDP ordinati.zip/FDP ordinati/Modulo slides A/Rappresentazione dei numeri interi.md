Per rappresentare i numeri interi in binario abbiamo a disposizione più tecniche : 
1) [[La tecnica modulo e segno]]
2) [[La tecnica del complemento a 2]]
3) [[La rappresentazione con bias]]


