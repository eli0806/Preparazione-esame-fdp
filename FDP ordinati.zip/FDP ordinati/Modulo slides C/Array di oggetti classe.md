E' possibile avere **array di oggetti classe**. --> Costruttori e distruttori, se definiti **vengono invocati per ogni singolo elemento dell'array.

Inoltre **può anche essere allocato in memoria libera.** --> Ha solo il costruttore di default.

**Esempi:**

![[Esempio array di classi 1.png]]

==Nota:== Scrivi non è mostrato nell'esempio ma equivarrebbe alla stampa .

![[Esempio array di classi 2.png]]