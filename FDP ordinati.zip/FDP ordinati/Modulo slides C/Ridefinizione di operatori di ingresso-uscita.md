E' possibile ridefinire gli operatori delle [[classi per l'ingresso e l'uscita di dati]].

**Come?**

Attraverso il meccanismo dell'overloading.

![[ridef oper.png]]

![[ridef oper 2.png]]