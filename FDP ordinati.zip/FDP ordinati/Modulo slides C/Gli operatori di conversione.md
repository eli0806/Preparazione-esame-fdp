Gli **operatori di conversione** sono operatori che posso usare per trasformare **un oggetto classe** in un **oggetto di tipo fondamentale**. --> Conversione esplicita ( vedere [[conversioni esplicite]]).

Essi seguono la sintassi: 

**operator** tipo(); //==Nota:== Il tipo di ritorno è sottinteso

**Esempio:**

![[operatori di conversione.png]]