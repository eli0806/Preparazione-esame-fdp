Le **istruzioni strutturate** consentono di **specificare azioni complesse** e fanno riferimento al [[teorema di Böhm–Jacopini]].

Sotto la categoria delle **istruzioni strutturate** troviamo:
- Le [[istruzioni composte]]--> che sono **sequenze di istruzioni**
- Le [[istruzioni condizionali]] --> che permettono di svolgere una sequenza di **istruzioni al verificarsi di una condizione**.
- Le [[istruzioni ripetitive]] -> che si usano **quando un azione va ripetuta più volte**.

