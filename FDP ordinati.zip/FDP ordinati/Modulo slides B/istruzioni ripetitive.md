Le **istruzioni ripetitive** vengono chiamate più banalmente **cicli** e permettono di **ripetere ricorsivamente una sequenza** (o un blocco) **di istruzioni fino al verificarsi di una condizione di controllo**.

In c++ abbiamo **3 tipi** di istruzioni ripetitive:
- [[L'istruzione while]].
- [[L'istruzione do]].
- [[L'istruzione for]].