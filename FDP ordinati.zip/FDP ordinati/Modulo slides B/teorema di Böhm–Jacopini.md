Il **teorema di Böhm–Jacopini** afferma che **qualsiasi algoritmo può essere espresso usando solo tre strutture di controllo: sequenza, selezione e iterazione** e ha dimostrato che **la complessità degli algoritmi non richiede complessità nei costrutti di controllo**.

