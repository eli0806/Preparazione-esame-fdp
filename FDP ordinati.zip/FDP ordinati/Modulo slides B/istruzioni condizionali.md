Le **istruzioni condizionali** ci permettono di **specificare azioni diverse** a seconda **del risultato di certe condizioni logiche.**

In c++ abbiamo **2 tipi** di istruzioni condizionali:
- [[L'istruzione if (if-statement)]].
- [[L'istruzione swtich(switch-statement)]]
