Come ci fa capire il nome, l'aritmetica degli indirizzi ci permette di agire su indirizzi o su [[puntatori]] che hanno per valore un indirizzo.

p+1 --> Oggetto dello stesso tipo di p ma consecutivo nello stack di memoria.

L'uso dell'aritmetica degli indirizzi è **specifico dei casi dove abbiamo più oggetti dello stesso tipo in celle di memoria adiacenti.**
