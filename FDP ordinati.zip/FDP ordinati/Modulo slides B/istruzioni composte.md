Le **istruzioni composte** consentono, **tramite la coppia di separatori { }**,  di **trasformare una sequenza di istruzioni** in **una singola istruzione**.

Esempio: 

int main (){
	{
	  ...codice //Questo blocco di codice rappresenta **l'istruzione complessa**.
	}
   }
Con le istruzioni composte si può parlare del concetto di [[visibilità]].
